/**
 * Created by 000 on 2017/9/21.
 */

    window.onload=function(){
        function cla(e){
            return document.getElementsByClassName(e)
        }
        var resizeEvt='orientationchange' in window ? 'orientationchange':'resize',

            ban=cla("banner")[0],
            ul=ban.children[0],
            ulLis=ul.children,
            len=ulLis.length,
            w=ban.offsetWidth,
            index= 1,start= 0,end= 0,move= 0,cha= 0,step= 0,fa=true;
        var timer=setInterval(next,1500);
        window.addEventListener(resizeEvt,function(){
            w=ban.offsetWidth;
            //console.log(w);
        });
        console.log(1);
        ban.addEventListener("touchstart",function(e){
            start= e.touches[0].pageX;
            clearInterval(timer);
        });
        console.log(w);
        ban.addEventListener("touchend",function(e){
            end= e.changedTouches[0].pageX;
            cha=end-start;
            if(cha>1/3*w&&fa==true){
                fa=false;
                prev();
            }else if(cha<-1/3*w&&fa==true){
                fa=false;
                next();
            }else{
                ul.style.transition="left .5s linear 0s";
                ul.style.left=-index*w+"px";
            }
            timer=setInterval(next,1500)
        });
        ban.addEventListener("touchmove",function(e){
            move= e.touches[0].pageX;
            step=move-start;
            ul.style.left=-index*w+step+"px";
        });
        ul.addEventListener("transitionend",function(){
            if(index<=0){
                index=len-2;
            }
            if(index>=len-1){
                index=1;
            }
            ul.style.transition="none";
            ul.style.left=-index*w+"px";
            fa=true;
        });
        function prev(){
            index--;
            ul.style.transition="left .5s linear 0s";
            ul.style.left=-index*w+"px";
        }
        function next(){
            index++;
            ul.style.transition="left .5s linear 0s";
            ul.style.left=-index*w+"px";
        }
    }
